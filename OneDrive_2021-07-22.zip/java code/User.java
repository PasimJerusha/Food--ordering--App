package com.foodon.app;

public class User  {

    String Role;

    public User(String role)
    {
        Role=role;
    }
}
