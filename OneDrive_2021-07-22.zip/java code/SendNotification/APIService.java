package com.foodon.app.SendNotification;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {

    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAA6mg8rIg:APA91bH3Y9zBPHvkypxamYp5_x8TyuaVJ_U9qvATGbZYqAmSejs0nFuCj00y0AalD7KU1QpMEq1JPuFSIvCPnl_FMpAPVnC4PNcwx3cDIwq0mBAjdBSkk1-oTja17hFIutVbSk5qY_ys"
            }
    )

    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body NotificationSender body);
}
