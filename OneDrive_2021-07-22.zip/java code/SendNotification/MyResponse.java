package com.foodon.app.SendNotification;

public class MyResponse {

    public int success;
}
